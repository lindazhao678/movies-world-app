import React, { FC } from 'react'

const PageNotFound: FC = () => {
    return (
        <div>404</div>
    )
}

export default PageNotFound